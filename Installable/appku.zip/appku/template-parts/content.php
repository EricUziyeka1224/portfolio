<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package appku
 */

global $appku_opt;
$appku_excerpt_length = !empty( $appku_opt['appku_excerpt_length'] ) ? $appku_opt['appku_excerpt_length'] : 32;
$social_share = !empty( $appku_opt['social_share'] ) ? $appku_opt['social_share'] : '';

if (is_singular()) { ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="blog-wrapper mb-60">
	        <?php if ( has_post_thumbnail() ): ?>
			<div class="blog-thumb">
		        <?php the_post_thumbnail() ?>
		    </div>
		    <div class="post-meta">
	            <ul>
	                <li><?php echo esc_html__( 'By','appku' ); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" class="link"><?php the_author(); ?></a></li>
		            <li><?php echo get_the_date(); ?></li>
		            <li><?php comments_number( 'No Comments', 'One Comment', '% Comments' ); ?></li>
	            </ul>
	        </div>
			<?php endif ?>
	        
	        <div class="blog-content blog-d-content">
	            <?php
				the_content( sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'appku' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					get_the_title()
				) );

				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'appku' ),
					'after'  => '</div>',
				) );
				?>

	            <div class="row mt-25">
	            	<?php if ( has_tag() ): ?>
	            	<div class="col-lg-6">
	                    <div class="blog-post-tag">
	                        <span><?php echo esc_html__( 'Tag :', 'appku' ) ?></span>
	                        <?php echo get_the_tag_list('<ul><li>','</li> , <li>','</li></ul>');?>
	                    </div>
	                </div>
	            	<?php endif ?>
	                
	                <?php if ( true == $social_share ): ?>
	                <div class="col-lg-6">
	                    <div class="blog-share">
	                        <span><?php echo esc_html__( 'Share :', 'appku' ) ?></span>
	                        	<?php echo appku_social_sharing(); ?>
	                    </div>
	                </div>
	            	<?php endif ?>
	            </div>
	        </div>
	    </div>
	</article>
	
<?php } else { ?>

	<div id="post-<?php the_ID(); ?>" <?php post_class('blog-wrapper mb-60'); ?>>
		<?php if ( has_post_thumbnail() ): ?>
		<div class="blog-thumb">
			<a href="<?php the_permalink() ?>">
		        <?php the_post_thumbnail() ?>
		    </a>
	    </div>
	    <div class="post-meta">
	        <ul>
	            <li><?php echo esc_html__( 'By','appku' ); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" class="link"><?php the_author(); ?></a></li>
	            <li><?php echo get_the_date(); ?></li>
	            <li><?php comments_number( 'No Comments', 'One Comment', '% Comments' ); ?></li>
	        </ul>
	    </div>
		<?php endif ?>

	    <div class="blog-content">
	        <h2 class="excerpt-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
	        <p><?php echo wp_trim_words( get_the_excerpt(), $appku_excerpt_length, '...' ); ?></p>
	        <a href="<?php the_permalink() ?>" class="btn"><?php echo esc_html__( 'Read more','appku' ) ?></a>
	    </div>
	</div>

<?php } ?>