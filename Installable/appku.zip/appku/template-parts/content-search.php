<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package appku
 */

global $appku_opt;
$appku_excerpt_length = !empty( $appku_opt['appku_excerpt_length'] ) ? $appku_opt['appku_excerpt_length'] : 32;
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('blog-wrapper mb-60'); ?>>
	<?php if ( has_post_thumbnail() ): ?>
	<div class="blog-thumb">
		<a href="<?php the_permalink() ?>">
	        <?php the_post_thumbnail() ?>
	    </a>
    </div>
    <div class="post-meta">
        <ul>
            <li><?php echo esc_html__( 'By','appku' ); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" class="link"><?php the_author(); ?></a></li>
            <li><?php echo get_the_date(); ?></li>
            <li><?php comments_number( 'No Comments', 'One Comment', '% Comments' ); ?></li>
        </ul>
    </div>
	<?php endif ?>

    <div class="blog-content">
        <h2 class="excerpt-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
        <p><?php echo wp_trim_words( get_the_excerpt(), $appku_excerpt_length, '...' ); ?></p>
        <a href="<?php the_permalink() ?>" class="btn"><?php echo esc_html__( 'Read more','appku' ) ?></a>
    </div>
</div>