<?php
if ( post_password_required() ) {
	return;
}

// callback comment list
class comment_walker extends Walker_Comment {

	var $tree_type = 'comment';
	var $db_fields = array( 'parent' => 'comment_parent', 'id' => 'comment_ID' );


	// start_lvl – wrapper for child comments list
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>
		
		<div class="single__comment children mb-35 mt-35">

	<?php }

	// end_lvl – closing wrapper for child comments list
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>

		</div>

	<?php }

	// start_el – HTML for comment template
	function start_el( &$output, $comment, $depth = 0, $args = array(), $id = 0 ) {
		$depth++;
		$GLOBALS['comment_depth'] = $depth;
		$GLOBALS['comment'] = $comment;
		$parent_class = ( empty( $args['has_children'] ) ? '' : 'parent' ); ?>

		<div class="single__comment mb-35" itemprop="comment" itemscope itemtype="http://schema.org/Comment">
			<div class="comments-avatar">
                <?php 
                if ( $args['avatar_size'] != 0 ) {
           			echo get_avatar( $comment, $args['avatar_size'] ); }
                ?>
            </div>

            <div class="comment-text">
                <div class="avatar-name mb-15">
                    <h6><?php comment_author(); ?></h6>
                    <span><?php comment_date('jS F Y') ?></span>
                    <?php comment_reply_link(array_merge( $args, array('add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                </div>
                <?php comment_text() ?>
                <?php if ($comment->comment_approved == '0') : ?>
					<p class="comment-meta-item">Your comment is awaiting moderation.</p>
				<?php endif; ?>
            </div>

	<?php }

	// end_el – closing HTML for comment template
	function end_el(&$output, $comment, $depth = 0, $args = array() ) { ?>

		</div>

	<?php }

}

?>

<?php
// You can start editing here -- including this comment!
if ( have_comments() ) : ?>
	<h3 class="widget-title">
		<?php
		$appku_comment_count = get_comments_number();
		if ( '1' === $appku_comment_count ) {
			printf(
				esc_html__( 'One comment on &ldquo;%1$s&rdquo;', 'appku' ),
				'<span>' . get_the_title() . '</span>'
			);
		} else {
			printf(
				esc_html( _nx( '%1$s comments', '%1$s comments', $appku_comment_count, 'comments title', 'appku' ) ),
				number_format_i18n( $appku_comment_count ),
				'<span>' . get_the_title() . '</span>'
			);
		}
		?>
	</h3><!-- .comments-title -->

	<?php the_comments_navigation(); ?>

	<?php
	wp_list_comments( array(
		'style'       => 'div',
		'walker'      => new comment_walker(),
		'short_ping'  => true,
		'format'      => 'html5',
		'type'        => 'comment',
		'avatar_size' => 100,
	) );
	?>

	<?php
	the_comments_navigation();
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() ) :
		?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'appku' ); ?></p>
		<?php
	endif;
endif; // Check for have_comments().
comment_form( array(
  'id_form'           => 'commentform',
  'class_form'        => 'post-comment-form row',
  'submit_button' 	  => '<button class="btn" type="submit">%4$s</button>',
  'label_submit'      => esc_html__( 'Post Comments','appku' ),
  'title_reply' => __( 'Post Comment' , 'appku' ),
  'format'            => 'html5',
  'comment_notes_before' => false,
  'comment_field' =>  '
	  <div class="col-xl-12 mb-20">
	  	<textarea id="comment" name="comment" placeholder="'. esc_attr__( 'Type your comments....' ,'appku' ) .'" aria-required="true">' . '</textarea>
	  </div>',

  'fields' => apply_filters( 'comment_form_default_fields', array(
	  'author' =>
	    '<div class="col-lg-6 mb-20">
            <input id="author" name="author" type="text" placeholder="'. esc_attr__( 'Type your name....' ,'appku' ) .'" value="' . esc_attr( $commenter['comment_author'] ) . '" aria-required="true" />
	    </div>',

	  'email' =>
	    '<div class="col-lg-6 mb-20">
            <input id="email" name="email" type="text" placeholder="'. esc_attr__( 'Type your email....' ,'appku' ) .'" value="' . esc_attr(  $commenter['comment_author_email'] ) .
	    '" aria-required="true" />
	    </div>',

	  'url' =>
		'<div class="col-xl-12 mb-20">
			<input id="url" name="url" type="text" placeholder="'. esc_attr__( 'Type your website....' ,'appku' ) .'" value="' . esc_attr( $commenter['comment_author_url'] ) .
		    '" size="30" />
		</div>',
		)
	),
));
?>