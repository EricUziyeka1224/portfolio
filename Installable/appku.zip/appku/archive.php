<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package appku
 */

get_header();
?>
<!-- blog-area -->
<section class="blog-area pt-120 pb-125">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-7">
                <?php
				if ( have_posts() ) : while ( have_posts() ) : the_post();
					
						get_template_part( 'template-parts/content', get_post_type() );

					endwhile;

				else :

					get_template_part( 'template-parts/content', 'none' );

				endif;
				?>
                
                <div class="pagination">
                    <?php echo appku_pagination() ?>
                </div>
            </div>

            <div class="col-lg-4 col-md-5 sidebar">
                <?php get_sidebar(); ?>
            </div>

        </div>
    </div>
</section>

<?php get_footer();