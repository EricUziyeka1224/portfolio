<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package appku
 */

global $appku_opt;

$appku_copyright_info = !empty($appku_opt['appku_copyright_info']) ? $appku_opt['appku_copyright_info'] : '';
$footer_widget_menu = !empty( $appku_opt['footer_widget_menu'] ) ? $appku_opt['footer_widget_menu'] : '';

?>

		<!-- footer -->
	    <footer class="footer-bg">
	        <div class="container">
	        	<?php if ( is_active_sidebar( 'footer' ) ): ?>
	        		<div class="footer-area-wrap pt-95 pb-70">
		                <div class="row">
							<?php dynamic_sidebar( 'footer' ); ?>
		                </div>
		            </div>
	        	<?php endif ?>	            
	            <div class="row align-items-center">
	                <div class="col-lg-6 text-center text-lg-left">
	                    <div class="copyright-text">
	                    	<p>
							<?php
						    if( $appku_copyright_info ) {
						        echo wp_kses( $appku_copyright_info , array(
						            'a'       => array(
						                'href'    => array(),
						                'title'   => array()
						            ),
						            'br'      => array(),
						            'em'      => array(),
						            'strong'  => array(),
						            'img'     => array(
						                'src' => array(),
						                'alt' => array()
						            ),
						        ));
						    } else {
						    	echo esc_html__( 'Copyright 2019 All right reserved by ThemeBing','appku' ); 
							} ?>
						    </p>
	                    </div>
	                </div>
	                <?php if ( true == $footer_widget_menu ): ?>
		                <div class="col-lg-6 text-center text-lg-right d-none d-md-block">
		                    <div class="privacy-link">
		                    <?php wp_nav_menu( array(
		                    	'theme_location'    => 'footer'
		                    ) ); ?>
		                    </div>
		                </div>
	                <?php endif ?>
	            </div>
	        </div>
	    </footer>
	    <!-- footer-end -->
<?php wp_footer(); ?>

	</body>
</html>