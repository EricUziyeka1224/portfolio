<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package appku
 */

global $appku_opt;

$title = !empty($appku_opt['blog_breadcrumb_title']) ? $appku_opt['blog_breadcrumb_title'] : esc_html__( 'Blog & News', 'appku' );
$appku_header_full_width = !empty( $appku_opt['appku_header_full_width'] ) ? $appku_opt['appku_header_full_width'] : '';
$navbar_button = !empty( $appku_opt['navbar_button'] ) ? $appku_opt['navbar_button'] : '';
$navbar_button_text = !empty( $appku_opt['navbar_button_text'] ) ? $appku_opt['navbar_button_text'] : '';
$navbar_button_url = !empty( $appku_opt['navbar_button_url'] ) ? $appku_opt['navbar_button_url'] : '';

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> data-spy="scroll" data-target=".navbar" data-offset="50">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'appku' ); ?></a>
	<!-- preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
                <div class="object" id="object_one"></div>
                <div class="object" id="object_two"></div>
                <div class="object" id="object_three"></div>
                <div class="object" id="object_four"></div>
                <div class="object" id="object_five"></div>
                <div class="object" id="object_six"></div>
                <div class="object" id="object_seven"></div>
                <div class="object" id="object_eight"></div>
                <div class="object" id="object_big"></div>
            </div>
        </div>
    </div>
    <!-- header -->
    <header id="sticky-header" class="transparent-menu pt-20 pb-20">
        <div class="container<?php if( true == $appku_header_full_width ){ echo'-fluid'; } ?>">
            <div class="row">
                <div class="col-xl-12">
                    <div class="main-menu">
                        <nav class="navbar navbar-expand-lg">
                        	<?php 
			                if ( has_custom_logo() ){
				            	the_custom_logo();
				            } else { ?>
				            	<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				          	<?php } ?>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                                <span class="navbar-icon"></span>
                                <span class="navbar-icon"></span>
                                <span class="navbar-icon"></span>
                            </button>
                            <div class="navbar-collapse collapse" id="navbarNav">
                                <?php
    							wp_nav_menu( array(
    								'theme_location'    => 'primary',
    								'depth'             => 2,
    								'container'         => 'ul',
    								'container_id'      => 'navbarNav',
    								'menu_class'        => 'navbar-nav ml-auto',
    								'walker'            => new Appku_Bootstrap_Navwalker(),
    							) );
    							?>
                            </div>
                            <?php if ( true == $navbar_button ) { ?>
                            <div class="header-btn d-none d-xl-block">
                                <a href="<?php echo esc_url( $navbar_button_url ) ?>" class="btn">    <?php echo esc_html( $navbar_button_text ) ?>
                                </a>
                            </div>
                            <?php } ?>                            
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->
    <?php if (!is_page_template( 'custom-homepage.php' )) { ?>
	<!-- breadcrumb-area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-title">
                        <h2>
                        <?php
                          if(is_home() && is_front_page()){ echo esc_html($title); } else if(is_home()){ echo wp_title('', false); } else { echo wp_title('', false);
                          } ?>
                        </h2>
                    </div>
                    <?php appku_breadcrumb() ?>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb-area-end -->
    <?php } ?>