<?php
/**
 * appku functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package appku
 */

if ( ! function_exists( 'appku_setup' ) ) :

	function appku_setup() {
		
		load_theme_textdomain( 'appku', get_template_directory() . '/languages' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'appku' ),
			'footer' => esc_html__( 'Footer', 'appku' ),
		) );
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );
		add_theme_support( 'custom-background', apply_filters( 'appku_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
		add_image_size( 'appku-770x430', 770,430, true );
		add_image_size( 'appku-370x225', 370,225, true );
		add_image_size( 'appku-100x75', 100,75, true );
	}
endif;
add_action( 'after_setup_theme', 'appku_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function appku_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'appku_content_width', 640 );
}
add_action( 'after_setup_theme', 'appku_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function appku_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'appku' ),
		'id'            => 'sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'appku' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer', 'appku' ),
		'id'            => 'footer',
		'description'   => esc_html__( 'Add footer widgets here.', 'appku' ),
		'before_widget' => '<div id="%1$s" class="widget footer-widget col-lg-3 col-sm-6 %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget-heading">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'appku_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function appku_scripts() {
	wp_enqueue_style( 'appku-fonts', "//fonts.googleapis.com/css?family=Nunito:400,600,700,800|Poppins:400,400i,500,600,700", '', wp_get_theme()->get( 'Version' ), 'screen' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css');
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/fontawesome-all.min.css');
	wp_enqueue_style( 'themify-icons', get_template_directory_uri() . '/css/themify-icons.css');
	wp_enqueue_style( 'slick', get_template_directory_uri() . '/css/slick.css');
	wp_enqueue_style( 'appku-theme-default', get_template_directory_uri() . '/css/default.css');
	wp_enqueue_style( 'appku-theme-style', get_template_directory_uri() . '/css/style.css');
	wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css');
	wp_enqueue_style( 'appku-style', get_stylesheet_uri() );

	
	wp_enqueue_script( 'modernizr', get_theme_file_uri('/js/modernizr-3.5.0.min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'bootstrap', get_theme_file_uri('/js/bootstrap.min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'one-page-nav', get_theme_file_uri('/js/one-page-nav-min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'slick', get_theme_file_uri('/js/slick.min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'scrollUp', get_theme_file_uri('/js/jquery.scrollUp.min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'countdown', get_theme_file_uri('/js/jquery.countdown.min.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'appku-plugins', get_theme_file_uri('/js/plugins.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'appku-main.js', get_theme_file_uri('/js/main.js') , array('jquery'), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'appku-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_add_inline_style( 'appku-style', appku_inline_style());
}
add_action( 'wp_enqueue_scripts', 'appku_scripts' );


// Add span to archive post count
function appku_style_the_archive_count($links) {
    $links = str_replace('</a>&nbsp;(', '</a> <span>(', $links);
    $links = str_replace(')', ')</span>', $links);
    return $links;
}

add_filter('get_archives_link', 'appku_style_the_archive_count');

require get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';
require get_template_directory() . '/inc/custom-header.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/theme-option.php';
require get_template_directory() . '/inc/inline-script.php';
require get_template_directory() . '/inc/required-plugin-install.php';
require get_template_directory() . '/inc/breadcrumbs.php';