<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package appku
 */


global $appku_opt;

$related_posts = !empty($appku_opt['related_posts']) ? $appku_opt['related_posts'] : '';

get_header();
?>
	<!-- blog-area -->
	<section class="blog-area pt-120 pb-120">
	    <div class="container">
	        <div class="row">
	            <div class="col-lg-8 col-md-7">

				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part( 'template-parts/content', get_post_type() );
					
					if ( true == $related_posts ) {
						appku_related_posts();
					}

					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

				endwhile; // End of the loop.
				?>
				</div>

				<div class="col-lg-4 col-md-5 sidebar">
					<?php get_sidebar(); ?>
				</div>

			</div>
        </div>
    </section>

<?php get_footer();
