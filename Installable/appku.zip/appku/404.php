<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package appku
 */

global $appku_opt;

$appku_error_title = !empty( $appku_opt['appku_error_title'] ) ? $appku_opt['appku_error_title'] : 'Oops! That page can&rsquo;t be found.';
$appku_error_text = !empty( $appku_opt['appku_error_text'] ) ? $appku_opt['appku_error_text'] : 'It looks like nothing was found at this location. Maybe try one of the links below or a search?';
get_header(); ?>
<!-- blog-area -->
<section class="blog-area pt-120 pb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center error">
            	<span><?php esc_html_e( '404', 'appku' ); ?></span>
				<h1><?php echo esc_html( $appku_error_title ); ?></h1>
				<p><?php echo esc_html( $appku_error_text ); ?></p>
			</div>
		</div>
    </div>
</section>
<?php get_footer();
