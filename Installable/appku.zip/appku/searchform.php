<?php 
	/**
	 * The template for displaying Search form.
	 *
	 *
	 * @link https://codex.wordpress.org/Template_Hierarchy
	 *
	 * @package appku
	 */
?>
	<div class="sidebar-form">
        <form action="<?php echo esc_url(home_url( '/' )); ?>">
            <input type="text" name="s" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'appku' ); ?>">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>