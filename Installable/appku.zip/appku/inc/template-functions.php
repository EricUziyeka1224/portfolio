<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package appku
 */

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function appku_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'appku_pingback_header' );


// One click demo import
function appku_import_files() {
  return array(
    array(
      'import_file_name'             => 'Demo',
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo/content.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo/widgets.wie',
      'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo/customizer.dat',
      'local_import_redux'           => array(
        array(
          'file_path'   => trailingslashit( get_template_directory() ) . 'inc/demo/redux.json',
          'option_name' => 'appku_opt',
        ),
      )
    )
  );
}
add_filter( 'pt-ocdi/import_files', 'appku_import_files' );

// Default Home and Blog Setup
function appku_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Primary', 'primary' );

    set_theme_mod( 'nav_menu_locations', array(
            'main_menu' => $main_menu->term_id,
        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );
}
add_action( 'pt-ocdi/after_import', 'appku_after_import_setup' );



/*
 * custom pagination with bootstrap .pagination class
 * source: http://www.ordinarycoder.com/paginate_links-class-ul-li-bootstrap/
 */
function appku_pagination( $echo = true ) {
  global $wp_query;

  $big = 999999999; // need an unlikely integer

  $pages = paginate_links( array(
      'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
      'format' => '?paged=%#%',
      'current' => max( 1, get_query_var('paged') ),
      'total' => $wp_query->max_num_pages,
      'type'  => 'array',
      'prev_next'   => true,
      'prev_text'   => '<i class="fas fa-chevron-left"></i>',
      'next_text'   => '<i class="fas fa-chevron-right"></i>',
    )
  );

  if( is_array( $pages ) ) {
    $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');

    $pagination = '<ul>';

    foreach ( $pages as $page ) {
      $pagination .= "<li>$page</li>";
    }

    $pagination .= '</ul>';

    if ( $echo ) {
      echo $pagination;
    } else {
      return $pagination;
    }
  }
}

// Related Posts
function appku_related_posts() {
  global $appku_opt;

  $related_posts = !empty( $appku_opt['related_posts'] ) ? $appku_opt['related_posts'] : '';
  $related_post_title = !empty( $appku_opt['related_post_title'] ) ? $appku_opt['related_post_title'] : ''; ?>

  <?php if ( true == $related_posts ): ?>   

  <div class="related-post-wrapper">
      <div class="widget-title">
          <h5><?php echo esc_html( $related_post_title ); ?></h5>
      </div>
      <div class="row">

        <?php

        global $post;

        $tags = wp_get_post_terms( $post->ID , 'post_tag', ['fields' => 'ids'] );
        $related = new wp_query( [
            'post__not_in'        => array( $post->ID ),
            'posts_per_page'      => 2,
            'ignore_sticky_posts' => 1,
            'tax_query' => [
                [
                    'taxonomy' => 'post_tag',
                    'terms'    => $tags
                ]
            ]
        ] );

        while( $related->have_posts() ) { $related->the_post(); ?>

          <div class="col-lg-6">
              <div class="widget mb-50">
                  <div class="sidebar-rc-post">
                      <div class="rc-post-thumb">
                          <?php the_post_thumbnail( 'appku-370x225' ) ?>
                      </div>
                      <div class="rc-post-content">
                          <h5><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h5>
                          <div class="post-meta mb-0">
                              <ul>
                                <li><?php echo esc_html__( 'By','appku' ); ?> <a href="<?php echo   get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" class="  link"><?php the_author(); ?></a></li>
                                <li><?php comments_number( 'No Comments', 'One Comment', '% Comments  ' ); ?></li>
                                <li><?php echo get_the_date(); ?></li>
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        <?php } wp_reset_postdata(); ?>
      </div>
  </div>
  <?php endif ?>
<?php }

// comment form title
function appku_commentform_title( $args ) {
        
   $args['title_reply_before'] = '<div class="widget-title"><h5 id="reply-title" class="comment-reply-title">';
         $args['title_reply_after']  = '</h5></div>';

  return  $args;
  
}
add_filter( 'comment_form_defaults', 'appku_commentform_title' );

//Comment Field to Bottom
function appku_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}
add_filter( 'comment_form_fields', 'appku_comment_field_to_bottom' );