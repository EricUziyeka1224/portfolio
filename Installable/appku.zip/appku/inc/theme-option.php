<?php

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = "appku_opt";
    $theme = wp_get_theme();

    $args = array(
        'opt_name'             => $opt_name,
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( 'Version' ),
        'menu_type'            => 'menu',
        'allow_sub_menu'       => true,
        'menu_title'           => esc_html__( 'Appku Options', 'appku' ),
        'page_title'           => esc_html__( 'Appku Options', 'appku' ),
        'google_api_key'       => '',
        'google_update_weekly' => false,
        'async_typography'     => true,
        'admin_bar'            => true,
        'admin_bar_icon'       => 'dashicons-portfolio',
        'admin_bar_priority'   => 50,
        'global_variable'      => '',
        'dev_mode'             => false,
        'update_notice'        => true,
        'customizer'           => true,
        'page_priority'        => null,
        'page_parent'          => 'themes.php',
        'page_permissions'     => 'manage_options',
        'menu_icon'            => '',
        'last_tab'             => '',
        'page_icon'            => 'icon-themes',
        'page_slug'            => '_options',
        'save_defaults'        => true,
        'default_show'         => false,
        'default_mark'         => '',
        'show_import_export'   => true,
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        'output_tag'           => true,
        'database'             => '',
        'use_cdn'              => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );


    // General
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'General', 'appku' ),
        'id'     => 'general',
        'desc'   => esc_html__( 'General theme options.', 'appku' ),
        'icon'   => 'el el-home',
        'fields' => array(
            array(
                'id'       => 'site_preloader',
                'type'     => 'switch',
                'title'    => esc_html__( 'Preloader', 'appku' ),
                'default'  => true,
            ),

        )
    ));

    // Header
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Header', 'appku' ),
        'id'     => 'header',
        'desc'   => esc_html__( 'Header menu options.', 'appku' ),
        'icon'   => 'el el-heart-empty',
        'fields' => array(
            
            array(
                'id'       => 'appku_header_full_width',
                'type'     => 'switch',
                'title'    => esc_html__( 'Full Width Header', 'appku' ),
                'subtitle' => esc_html__( 'Controls the width of the header area. ', 'appku' ),
                'default'  => false,
            ),
            array(
                'id'       => 'navbar',
                'type'     => 'background',
                'output'   => '.sticky',
                'title'    => __('Navbar Background Color', 'appku'), 
                'subtitle' => __('Pick a color for background.', 'appku'),
                'background-repeat' => false,
                'background-attachment' => false,
                'background-size' => false,
                'background-position' => false,
                'background-image' => false,
                'default'  => '#EBF5FF',
            ),
            array(
                'id'       => 'navbar_link',
                'type'     => 'color',
                'output'   => '.sticky .main-menu .navbar-nav li.nav-item a.nav-link',
                'title'    => esc_html__('Navbar Link', 'appku'), 
                'subtitle' => esc_html__('Pick a color for navbar links.', 'appku'),
                'default'  => '#333',
                'validate' => 'color',
            ),
            array(
                'id'       => 'appku_header_sticky',
                'type'     => 'switch',
                'title'    => esc_html__( 'Sticky Header', 'appku' ),
                'subtitle' => esc_html__( 'Turn on to activate the sticky header.', 'appku' ),
                'default'  => false,
            ),
            array(
                'id'       => 'navbar_button',
                'type'     => 'switch',
                'title'    => esc_html__( 'Navbar button', 'appku' ),
                'default'  => false,
            ),
            array(
                'id'       => 'navbar_button_text',
                'type'     => 'text',
                'title'    => esc_html__('Navbar button Text', 'appku'),
                'default'  => esc_html__('Free Trail', 'appku'),
                'required' => array('navbar_button','equals', true)
            ),
            array(
                'id'       => 'navbar_button_url',
                'type'     => 'text',
                'title'    => esc_html__('Navbar button URL', 'appku'),
                'default'   => '#',
                'required' => array('navbar_button','equals', true)
            ),

        )
    ) );    

    // Style
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Style', 'appku' ),
        'id'     => 'style',
        'desc'   => esc_html__( 'Header menu options.', 'appku' ),
        'icon'   => 'el el-edit',
        'fields' => array(
            array(
                'id'       => 'primary_color',
                'type'     => 'color',
                'title'    => esc_html__('Primary Color', 'appku'), 
                'subtitle' => esc_html__('Pick a color for the theme (default: #1e73be).', 'appku'),
                'default'  => '#2775ff',
                'validate' => 'color',
            ),  
        )
    ));
    
    // Typography
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Typography', 'appku' ),
        'id'               => 'page_title_typography',  
        'icon'   => 'el el-pencil',
        'fields'           => array(
            array(
                'id'          => 'appku_heading_typography',
                'type'        => 'typography',
                'title'       => esc_html__( 'Heading Typography', 'appku' ),
                'subtitle'    => __('H1, H2, H3,H4, H5, H6  Tags', 'appku'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array('h1,h2,h3,h4,h5,h6'),
                'units'       =>'px',
                'default'     => array(
                    'color'       => '#333333', 
                    'font-weight'  => '800', 
                    'font-family' => 'Nunito', 
                    'google'      => true,
                ),
            ),
            array(
                'id'          => 'appku_typography',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography', 'appku' ),
                'subtitle'    => esc_html__('body, p Tags', 'appku'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array('body,p'),
                'units'       =>'px',
                'default'     => array(
                    'color'       => '#656565', 
                    'font-weight'  => '400', 
                    'font-family' => 'Poppins', 
                    'line-height' => '28px',
                    'google'      => true,
                    'font-size'   => '14px',
                ),
            )
        )
    ) );

    // Blog
    Redux::setSection( $opt_name, array(
        'title' => esc_html__( 'Blog', 'appku' ),
        'id'    => 'blog',
        'icon'  => 'el el-wordpress',
    ));

    // Blog Page
    Redux::setSection( $opt_name, array(
        'title' => esc_html__( 'Blog Page', 'appku' ),
        'id'    => 'blog_page',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'blog_breadcrumb_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Breadcrumb Title', 'appku' ),
                'default'  => esc_html__( 'Latest Blog', 'appku' ),
            ),
            array(
                'id'               => 'appku_excerpt_length',
                'type'             => 'slider',
                'title'            => esc_html__('Excerpt Length', 'appku'),
                'subtitle'         => esc_html__('Controls the excerpt length on blog page','appku'),
                "default"          => 32,
                "min"              => 10,
                "step"             => 2,
                "max"              => 130,
                'display_value'    => 'text'
            )
            
        )
    ) );

    // Single Blog
    Redux::setSection( $opt_name, array(
        'title' => esc_html__( 'Single Blog Page', 'appku' ),
        'id'    => 'single_blog_page',
        'subsection' => true,
        'fields'     => array(              
            array(
                'id'       => 'social_share',
                'type'     => 'switch',
                'title'    => esc_html__( 'Social Share', 'appku' ),
                'default'  => true,
            ),
            array(
                'id'       => 'appku_blog_details_post_navigation',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Navigation (Next/Previous)', 'appku' ),
                'default'  => true,
            ),
            array(
                'id'       => 'related_posts',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show Related Post', 'appku' ),
                'default'  => true,
            ),
            array(
                'id'       => 'related_post_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Related Post Title', 'appku' ),
                'required' => array( 'related_posts','equals', true ),
                'default'  => esc_html__( 'Related Post', 'appku' ),
            )
        )
    ) );
    
    // Footer
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Footer', 'appku' ),
        'id'     => 'footer',
        'icon'   => 'el el-arrow-down',
        'fields' => array(        
            array(
                'id'          => 'footer_widget_menu',
                'type'        => 'switch',
                'title'       => esc_html__( 'Footer menu', 'appku' ),
                'default'  => true,
            ),
            array(
                'id'              => 'appku_copyright_info',
                'type'            => 'editor',
                'required'        => array( 'footer_copyright_bar','equals', true ),
                'title'           => esc_html__( 'Copyright text', 'appku' ),
                'subtitle'        => esc_html__( 'Enter your company information here. HTML tags allowed: a, br, em, strong', 'appku' ),
                'default'         => esc_html__( 'Copyright © 2019 appku All Rights Reserved.', 'appku' ),
                'args'            => array(
                'wpautop'         => false,
                'teeny'           => true,
                'textarea_rows'   => 5
                )
            )
        )
    ) );

    // 404 
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( '404 Error', 'appku' ),
        'id'     => 'error-page',
        'icon'   => 'el el-error-alt',
        'fields' => array(
            array(
                'id'          => 'appku_error_title',
                'type'        => 'text',
                'title'       => esc_html__( 'Error title', 'appku' ),
                'default'     => esc_html__( 'Oops! That page can’t be found.', 'appku' ),
                ),
            array(
                'id'          => 'appku_error_text',
                'type'        => 'textarea',
                'title'       => esc_html__('Error message', 'appku'),
                'subtitle'    => esc_html__('Enter "not found" error message.', 'appku'),
                'default'     => esc_html__('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'appku'),
                )
            ),
    ) );
