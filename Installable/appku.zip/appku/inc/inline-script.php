<?php 
//inline style
function appku_inline_style() {
    ob_start();
    global $appku_opt;
    $primary_color = !empty($appku_opt['primary_color']) ? $appku_opt['primary_color'] : '#2775ff'; ?>
    
    .appku-btn,
    .btn,
    .btn.transparent-btn:hover,
    .blog-content .btn:hover,
    #scrollUp,
    .pricing-box.active .btn,
    #loading,
    .get-app:hover,
    .price-btn .btn:hover,
    .main-menu .navbar-nav li.nav-item a.nav-link::before,
    .pricing-box-2.active .price-btn-2 .btn,
    .price-btn-2.tp-btn .btn:hover,
    .pagination ul li span.current::before,
    .pagination ul li span.current::after,
	.widget .widget-title:after,
	.menu-action-btn,
	.navigation ul>li>a:after,
	.comment-navigation .nav-links a,
	.navigation ul li > ul li.current_page_item a:hover,
	.navigation ul li > ul li.current-menu-item a:hover,
	.navigation ul li > ul li.current_page_item a,
	.navigation ul li > ul li.current-menu-item a,
	.mean-container .mean-nav ul li a.mean-expand:hover,
	.content-tags a:hover,
	[type=reset],
	[type=submit],
	button,
	html [type=button],
	.dropdown-item.active,
	.comment-text .avatar-name .comment-reply-link:hover,
	.dropdown-item:active {
		background: <?php echo esc_attr( $primary_color ) ?>;
	}


	#backtotop i,
	.counter,
	.comment-text .avatar-name span,
	.address-icon i,
	.slider-content h1,
	.price-count h2,
	.navigation ul li.current-menu-item a,
	.navigation ul li.current_page_item a,
	.navigation.sticky ul li.current-menu-item a,
	.navigation.sticky ul li.current_page_item a
	.navbar-logo,
	.pagination .current,
	.section-title i,
	.navigation.sticky ul li > ul li a:hover,
	.navigation.sticky ul>li>a:hover
	.navigation ul li > ul li a:hover,
	.navigation ul>li>a:hover {
		color: <?php echo esc_attr( $primary_color ) ?>;
	}

	
	.get-app:hover,
	.comment-text .avatar-name .comment-reply-link:hover,
	.blog-content .btn:hover,
	.btn.transparent-btn:hover,
	.pricing-box.active .price-btn .btn,
	.testimonial-active .slick-dots li.slick-active button,
	.price-btn .btn:hover,
	.uil-ripple-css div,
	.uil-ripple-css div:nth-of-type(2),
	blockquote,
	.sticky {
		border-color: <?php echo esc_attr( $primary_color ) ?>;
	}

	/*----------------------------------------
	IF SCREEN SIZE LESS THAN 769px WIDE
	------------------------------------------*/
	@media screen and (max-width: 768px) {

	}
	
<?php
return ob_get_clean();
}