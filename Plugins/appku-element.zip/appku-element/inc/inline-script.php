<?php 
//inline style
function appku_core_inline_style() {
    ob_start();
    global $appku_opt;
    $primary_color = !empty($appku_opt['primary_color']) ? $appku_opt['primary_color'] : '#2775ff';

    ?>
	
	.appku-popup-video,
	.appku-btn.bordered:hover,
	.appku-accordion.style-3 .appku-accordion-item.active h5,
	.appku-pricing-table .appku-buy-button,
	.appku-pricing-table.recommended:after,
	.appku-play-btn-icon,
	.appku-team ul li a:hover,
	.appku-call-to-action a,
	.appku-item-Iconbox.style_1 .appku-item-iconbox-icon:before,
	.blog-item-meta-1,
	.booking-form input[type=submit],
	.service-list:hover .service-list-icon,
	.pricing-table.selected:after,
	.pricing-table .card .price,
	.pricing-table a,
	.accordion-item h6:hover,
	.accordion-item.active h6,
	.team ul li a:hover,
	.appku-btn,
	.appku-tabs .nav-link.active i,
	.appku-tabs .nav-link.active span,
	.call-to-action ul li a,
	.popup-icon,
	.banner ul li:first-child a,
	.banner ul li:last-child a:hover {
		background: <?php echo esc_attr( $primary_color ) ?>;
	}

	.star-rating i,
	.appku-btn.bordered,
	.appku-accordion-item.active h5,
	.appku-accordion-item.active h5 span,
	.appku-heading-title i,
	.appku-heading-title span,
	.tariff-item-content span,
	.service-list-icon i,
	.item-service .item-service-icon,
	a:hover,
	.appku-tabs .nav-link.active,
	.section-title h1 span {
		color: <?php echo esc_attr( $primary_color ) ?>;
	}

	
	.service-list-icon,
	.appku-btn.bordered,
	.appku-item-Iconbox.style_1 .appku-item-iconbox-icon,
	.item-service,
	.item-service .item-service-icon {
		border-color: <?php echo esc_attr( $primary_color ) ?>;
	}


	/*----------------------------------------
	IF SCREEN SIZE LESS THAN 769px WIDE
	------------------------------------------*/
	@media screen and (max-width: 768px) {

	}
	
<?php
return ob_get_clean();
}