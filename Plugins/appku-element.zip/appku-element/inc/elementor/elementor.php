<?php

if ( ! defined( 'ABSPATH' ) ) exit;

function appku_add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'appku-elements',
		[
			'title' => esc_html__( 'appku Elements', 'appku' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'appku_add_elementor_widget_categories' );



//Elementor init

class appku_ElementorCustomElement {
 
   private static $instance = null;
 
   public static function get_instance() {
      if ( ! self::$instance )
         self::$instance = new self;
      return self::$instance;
   }
 
   public function init(){
      add_action( 'elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ) );
   }


   public function widgets_registered() {

    // We check if the Elementor plugin has been installed / activated.
    if(defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')){

      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-heading.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-banner.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-post.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-feature.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-pricing.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-testimonials.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-counter.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-button.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-list.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-newsletter.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-review.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-carousel.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-cta.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-cf7.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-screenshot.php' );
      include_once( plugin_dir_path( __FILE__ ).'/widgets/widget-video.php' );

      }
	}

}
 
appku_ElementorCustomElement::get_instance()->init();