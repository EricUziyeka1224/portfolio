<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Pricing
class appku_Widget_Pricing extends Widget_Base {
 
   public function get_name() {
      return 'pricing';
   }
 
   public function get_title() {
      return esc_html__( 'Pricing', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-price-table';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'pricing_section',
         [
            'label' => esc_html__( 'Pricing', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'style',
         [
            'label' => __( 'Icon Box Style', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style_1',
            'options' => [
               'style_1' => __( 'Style 1', 'appku' ),
               'style_2' => __( 'Style 2', 'appku' )
            ],
         ]
      );

      $this->add_control(
         'title',
         [
            'label' => __( 'Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Startup'
         ]
      );

      $this->add_control(
         'sub_title',
         [
            'label' => __( 'Sub Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Basic Plan',
            'condition' => ['style' => 'style_1']
         ]
      );

      $this->add_control(
         'icon',
         [
            'label' => __( 'icon', 'appku' ),
            'type' => \Elementor\Controls_Manager::ICON,
            'label_block' => true,
            'default' => 'fa fa-shield',
            'condition' => ['style' => 'style_1']
         ]
      );

      $this->add_control(
         'image',
         [
            'label' => __( 'Upload Icon', 'appku' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'condition' => ['style' => 'style_2']
         ]
      );

      $this->add_control(
         'price',
         [
            'label' => __( 'Price', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '49.99'
         ]
      );
      
      $this->add_control(
         'currency',
         [
            'label' => __( 'Currency', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '&#x24;',
            'options' => [
               '&#x24;'  => '&#x24;',
               '&#xa2;'  => '&#xa2;',
               '&#xa3;'  => '&#xa3;',
               '&#x20AC;'  => '&#x20AC;',
               '&#xa5;'  => '&#xa5;',
               '&#x20B9;'  => '&#x20B9;',
               '&#x20BD;'  => '&#x20BD;',
               '&#x5143;'  => '&#x5143;',
               '&#xa4;'  => '&#xa4;',
               '&#x20A0;'  => '&#x20A0;',
               '&#x20A1;'  => '&#x20A1;',
               '&#x20A2;'  => '&#x20A2;',
               '&#x20A3;'  => '&#x20A3;',
               '&#x20A4;'  => '&#x20A4;',
               '&#x20A5;'  => '&#x20A5;',
               '&#x20A6;'  => '&#x20A6;',
               '&#x20A7;'  => '&#x20A7;',
               '&#x20A8;'  => '&#x20A8;',
               '&#x20A9;'  => '&#x20A9;',
               '&#x20AA;'  => '&#x20AA;',
               '&#x20AB;'  => '&#x20AB;',
               '&#x20AD;'  => '&#x20AD;',
               '&#x20AE;'  => '&#x20AE;',
               '&#x20AF;'  => '&#x20AF;',
            ],
         ]
      );
      
      $this->add_control(
         'package',
         [
            'label' => __( 'Package', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'Monthly',
            'options' => [
               'Daily'  => __( 'Daily', 'appku' ),
               'Weekly'  => __( 'Weekly', 'appku' ),
               'Monthly' => __( 'Monthly', 'appku' ),
               'Yealry' => __( 'Yealry', 'appku' ),
               '' => __( 'None', 'appku' )
            ],
         ]
      );

      $feature = new \Elementor\Repeater();

      $feature->add_control(
         'feature',
         [
            'label' => __( 'Feature', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => __( '10 Free Domain Names', 'appku' )
         ]
      );

      $this->add_control(
         'feature_list',
         [
            'label' => __( 'Feature List', 'appku' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $feature->get_controls(),
            'default' => [
               [
                  'feature' => __( 'Push Notifications', 'appku' )
               ],
               [
                  'feature' => __( 'Offline Synchronization', 'appku' )
               ],
               [
                  'feature' => __( 'SQL Database', 'appku' )
               ],
               [
                  'feature' => __( 'Speech & Text Analytics', 'appku' )
               ],
               [
                  'feature' => __( '24/7 Support', 'appku' )
               ]
            ],
            'title_field' => '{{{ feature }}}'
         ]
      );

      $this->add_control(
         'btn_text',
         [
            'label' => __( 'button text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Choose plan'
         ]
      );

      $this->add_control(
         'btn_url',
         [
            'label' => __( 'button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://example.com', 'appku' ),
            'show_external' => true,
            'default' => [
               'url' => '#',
               'is_external' => true,
               'nofollow' => true,
            ]
         ]
      );

      $this->add_control(
         'recommended',
         [
            'label' => __( 'Recommended', 'plugin-domain' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'On', 'appku' ),
            'label_off' => __( 'Off', 'appku' ),
            'return_value' => 'on',
            'default' => 'off',
         ]
      );

      $this->end_controls_section();
   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );
      $this->add_inline_editing_attributes( 'sub_title', 'basic' );
      $this->add_inline_editing_attributes( 'price', 'basic' );
      $this->add_inline_editing_attributes( 'btn_text', 'basic' );
      $this->add_inline_editing_attributes( 'btn_url', 'basic' );

      $target = $settings['website_link']['is_external'] ? ' target="_blank"' : '';
      $nofollow = $settings['website_link']['nofollow'] ? ' rel="nofollow"' : '';

      ?>
      
      <?php if ($settings['style'] == 'style_1'){ ?>

      <div class="pricing-box <?php if ( 'on' == $settings['recommended'] ){ echo"active"; }?> mb-30 text-center">
         <div class="price-head">
           <h2 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html( $settings['title'] ); ?></h2>
           <span <?php echo $this->get_render_attribute_string( 'sub_title' ); ?>><?php echo esc_html( $settings['sub_title'] ); ?></span>
         </div>
         <div class="price-count mb-35">
           <h2><?php echo esc_html($settings['currency']).esc_html( $settings['price'] ); ?>/<span><?php echo esc_html( $settings['package'] ); ?></span></h2>
         </div>
         <div class="price-list mb-45">
           <ul>
            <?php 
               foreach (  $settings['feature_list'] as $index => $feature ) { 
               $feature_inline = $this->get_repeater_setting_key( 'feature','feature_list',$index);
               $this->add_inline_editing_attributes( $feature_inline, 'basic' );
            ?>
               <li <?php echo $this->get_render_attribute_string( $feature_inline ); ?>><?php echo $feature['feature'] ?></li>
            <?php 
            } ?>
           </ul>
         </div>
         <div class="price-btn gradient">
           <a class="btn" href="<?php echo esc_attr( $settings['btn_url'] ) ?>" <?php echo $this->get_render_attribute_string( 'btn_text' ); ?><?php echo esc_attr( $target ) . esc_attr( $nofollow ) ?>><?php echo esc_html( $settings['btn_text'] ) ?></a>
         </div>
      </div>

      <?php } elseif ($settings['style'] == 'style_2'){ ?>

      <div class="pricing-box-2 <?php if ( 'on' == $settings['recommended'] ){ echo"active"; }?> text-center mb-30">
         <?php if ( 'on' == $settings['recommended'] ){ echo'<div class="rating-shape-2"></div>'; }?>            
            <div class="pricing-head-2 mb-35">
               <div class="price-icon-2 mb-45">
                   <?php echo wp_get_attachment_image( $settings['image']['id'], 'full' ); ?>
               </div>
               <h4 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html( $settings['title'] ); ?></h4>
            </div>
            <div class="pricing-list-2 mb-40">
               <ul>
               <?php 
                  foreach (  $settings['feature_list'] as $index => $feature ) { 
                  $feature_inline = $this->get_repeater_setting_key( 'feature','feature_list',$index);
                  $this->add_inline_editing_attributes( $feature_inline, 'basic' );
               ?>
                  <li <?php echo $this->get_render_attribute_string( $feature_inline ); ?>><i class="fas fa-check"></i><?php echo $feature['feature'] ?></li>
               <?php 
               } ?>
              </ul>
            </div>
            <div class="price-count-2 mb-45">
               <h5><?php echo esc_html($settings['currency']).esc_html( $settings['price'] ); ?></h5>
               <span><?php echo esc_html( $settings['package'] ); ?></span>
            </div>
            <div class="price-btn-2 tp-btn">
               <a class="btn" href="<?php echo esc_attr( $settings['btn_url'] ) ?>" <?php echo $this->get_render_attribute_string( 'btn_text' ); ?><?php echo esc_attr( $target ) . esc_attr( $nofollow ) ?>><?php echo esc_html( $settings['btn_text'] ) ?></a>
            </div>
      </div>

      <?php } ?>

      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Pricing );