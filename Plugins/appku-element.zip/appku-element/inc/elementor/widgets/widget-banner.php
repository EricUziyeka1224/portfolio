<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// banner
class appku_Widget_Banner extends Widget_Base {
 
   public function get_name() {
      return 'banner';
   }
 
   public function get_title() {
      return esc_html__( 'Banner', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-slider-album';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'banner_section',
         [
            'label' => esc_html__( 'Banner', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'mockup_image',
         [
            'label' => __( 'Mockup Image', 'appku' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ]
         ]
      );

      $this->add_control(
         'title',
         [
            'label' => __( 'Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Starting Your Smart Life With Appku', 'appku' ),
         ]
      );

      $this->add_control(
         'text',
         [
            'label' => __( 'Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => __( 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give omplete account.', 'appku' ),
         ]
      );

      $this->add_control(
         'button_1',
         [
            'label' => __( 'Button Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Discover more', 'appku' ),
         ]
      );

      $this->add_control(
         'button_url_1',
         [
            'label' => __( 'Button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' =>  '#',
         ]
      );

      $this->add_control(
         'button_2',
         [
            'label' => __( 'Button Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Download now', 'appku' ),
         ]
      );

      $this->add_control(
         'button_url_2',
         [
            'label' => __( 'Button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' =>  '#',
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );
      $this->add_inline_editing_attributes( 'text', 'basic' );
      $this->add_inline_editing_attributes( 'button_1', 'basic' );
      $this->add_inline_editing_attributes( 'button_2', 'basic' );
      ?>
      
      <!-- slider-area -->
      <div class="container">
        <div class="row">
            <div class="col-xl-7 col-lg-7">
                <div class="slider-content">
                   <h1 data-animation="fadeInLeft" data-delay=".2s" <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h1>
 
                   <p data-animation="fadeInLeft" data-delay=".4s" <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo esc_html($settings['text']); ?></p>
                    <div class="slider-btn">
                        <a href="<?php echo esc_url( $settings['button_url_1'] ); ?>" class="btn" data-animation="fadeInUp" data-delay=".6s" <?php echo $this->get_render_attribute_string( 'button_1' ); ?>><?php echo esc_html($settings['button_1']); ?></a>
                        <a href="<?php echo esc_url( $settings['button_url_2'] ); ?>" class="btn transparent-btn" data-animation="fadeInUp" data-delay=".8s" <?php echo $this->get_render_attribute_string( 'button_2' ); ?>><?php echo esc_html($settings['button_2']); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 <?php if ( $settings['textcolor'] !== 'colored' ){echo'offset-xl-1';} ?> col-lg-5 d-none d-lg-block">
                <div class="slider-img" data-animation="fadeInRight" data-delay=".8s">
                    <img src="<?php echo esc_url( $settings['mockup_image']['url'] ) ?>" alt="">
                </div>
            </div>
        </div>
      </div>
      <!-- slider-area-end -->

      <?php
   }

}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Banner );