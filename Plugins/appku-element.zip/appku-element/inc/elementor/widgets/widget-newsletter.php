<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Newsletter
class appku_Widget_Newsletter extends Widget_Base {
 
   public function get_name() {
      return 'newsletter';
   }
 
   public function get_title() {
      return esc_html__( 'Newsletter', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-mail';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'section',
         [
            'label' => esc_html__( 'Newsletter', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );


      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );

      ?>


      <?php
   }

}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Newsletter );