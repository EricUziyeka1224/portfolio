<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Button
class appku_Widget_Button extends Widget_Base {
 
   public function get_name() {
      return 'button';
   }
 
   public function get_title() {
      return esc_html__( 'Button', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-button';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'button_section',
         [
            'label' => esc_html__( 'Button', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'button_style',
         [
            'label' => __( 'Button Style', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style_1',
            'options' => [
               'style_1'  => __( 'Style 1', 'appku' ),
               'style_2' => __( 'Style 2', 'appku' )
            ],
         ]
      );

      $this->add_control(
         'button_text', [
            'label' => __( 'Button Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Download', 'appku' )
         ]
      );

      $this->add_control(
         'button_text_1', [
            'label' => __( 'Button Text Part 1', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Avaliable on', 'appku' ),
            'condition' => ['button_style' => 'style_2']
         ]
      );

      $this->add_control(
         'button_text_2', [
            'label' => __( 'Button Text Part 2', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Google Store', 'appku' ),
            'condition' => ['button_style' => 'style_2']
         ]
      );

      $this->add_control(
         'icon',
         [
            'label' => __( 'Choose Icon', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'ti-android',
            'condition' => ['button_style' => 'style_2']
         ]
      );


      $this->add_control(
         'button_url', [
            'label' => __( 'Button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '#',
         ]
      );      

      $this->add_control(
         'align',
         [
            'label' => __( 'Alignment', 'appku' ),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
               'left' => [
                  'title' => __( 'Left', 'appku' ),
                  'icon' => 'fa fa-align-left',
               ],
               'center' => [
                  'title' => __( 'Center', 'appku' ),
                  'icon' => 'fa fa-align-center',
               ],
               'right' => [
                  'title' => __( 'Right', 'appku' ),
                  'icon' => 'fa fa-align-right',
               ],
            ],
            'default' => 'left',
            'toggle' => true
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();

      //Inline Editing
      $this->add_inline_editing_attributes( 'button_text', 'basic' );
      ?>

      <div style="text-align: <?php echo esc_attr($settings['align']) ?>">
         <?php if ('style_1' == $settings['button_style']): ?>

            <a class="appku-btn" href="<?php echo esc_url( $settings['button_url'] ); ?>"><?php echo esc_html( $settings['button_text'] ); ?></a>

         <?php elseif('style_2' == $settings['button_style']): ?>

            <a class="get-app" href="<?php echo esc_url( $settings['button_url'] ); ?>">
              <i class="<?php echo esc_attr( $settings['icon'] ); ?>"></i>
              <p><?php echo esc_html( $settings['button_text_1'] ); ?> <br> <b><?php echo esc_html( $settings['button_text_2'] ); ?></b></p>
            </a>

         <?php endif ?>

      </div>

         

      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Button );