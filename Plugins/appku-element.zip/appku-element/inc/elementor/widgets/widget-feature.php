<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Icon Box
class appku_Widget_feature extends Widget_Base {
 
   public function get_name() {
      return 'feature';
   }
 
   public function get_title() {
      return esc_html__( 'Feature', 'appku' );
   }
 
   public function get_icon() { 
        return ' eicon-icon-box';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'feature_section',
         [
            'label' => esc_html__( 'Feature', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );
      
      $this->add_control(
         'style',
         [
            'label' => __( 'Feature Style', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style_1',
            'options' => [
               'style_1'  => __( 'Icon Center', 'appku' ),
               'style_2' => __( 'Icon Left', 'appku' ),
               'style_3' => __( 'Left Without Icon', 'appku' ),
               'style_4' => __( 'Icon Left font', 'appku' ),
            ],
         ]
      );

      $this->add_control(
         'image',
         [
            'label' => __( 'Upload Icon', 'appku' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'condition' => ['style' => [ 'style_1', 'style_2'] ]
         ]
      );

      $this->add_control(
         'icon',
         [
            'label' => __( 'icon', 'appku' ),
            'type' => \Elementor\Controls_Manager::ICON,
            'label_block' => true,
            'default' => 'fa-shield',
            'condition' => ['style' => 'style_4']
         ]
      );

      $this->add_control(
         'title',
         [
            'label' => __( 'Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Awesome Design', 'appku' ),
         ]
      );

      $this->add_control(
         'text',
         [
            'label' => __( 'Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => __( 'Give you a complete account of the system and expound the actual teachings of the great explorer of the truth the master.', 'appku' ),
         ]
      );

      
      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );
      $this->add_inline_editing_attributes( 'text', 'basic' );
      ?>
      <?php if ($settings['style'] == 'style_1'){ ?>

        <div class="features-wrap text-center">
            <div class="features-icon">
                <?php echo wp_get_attachment_image( $settings['image']['id'], 'full' ); ?>
            </div>
            <div class="features-content">
                <h2 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h2>
                <p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo esc_html($settings['text']); ?></p>
            </div>
        </div>

      <?php } elseif ($settings['style'] == 'style_2'){ ?>

         <div class="single-features">
             <div class="icon">
                 <?php echo wp_get_attachment_image( $settings['image']['id'], 'full' ); ?>
             </div>
             <div class="app-features-content">
                <h4 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h4>
                <p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo esc_html($settings['text']); ?></p>
             </div>
         </div>

      <?php } elseif ($settings['style'] == 'style_3'){ ?>
        
        <div class="single-details">
            <h4 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h4>
            <p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo esc_html($settings['text']); ?></p>
        </div>

      <?php } elseif ($settings['style'] == 'style_4'){ ?>
        
        <div class="single-features-wrap">
            <div class="sf-icon">
                <i class="fas <?php echo esc_html($settings['icon']); ?>"></i>
            </div>
            <div class="sf-content">
                <h5 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h5>
                <p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo esc_html($settings['text']); ?></p>
            </div>
        </div>

      <?php } ?>
         
      
      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_feature );