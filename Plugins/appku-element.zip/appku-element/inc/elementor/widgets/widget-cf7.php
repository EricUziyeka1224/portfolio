<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Contact Form 7
class appku_Widget_CF7 extends Widget_Base {
 
   public function get_name() {
      return 'contact_form_7';
   }
 
   public function get_title() {
      return esc_html__( 'Contact Form 7', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-form-horizontal';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'contact_form_7_section',
         [
            'label' => esc_html__( 'Contact Form 7', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

      $contact_forms = array();
      if ( $cf7 ) {
         foreach ( $cf7 as $cform ) {
            $contact_forms[ $cform->ID ] = $cform->post_title;
         }
      } else {
         $contact_forms[ esc_html__( 'No contact forms found', 'appku' ) ] = 0;
      }

      $this->add_control(
         'contact_form',
         [
            'label'     => esc_html__( 'Select Form', 'appku' ),
            'type'      => Controls_Manager::SELECT,
            'options'   => $contact_forms,
         ]
      );

      $this->end_controls_section();

   }

   private function get_shortcode() {
      $settings = $this->get_settings();

      if (!$settings['contact_form']) {
         return '<div class="alert alert-danger" role="alert">'.__('Please select a Contact Form From Setting!', 'appku').'</div>';
      }

      $attributes = [
         'id'  => $settings['contact_form'],
      ];

      $this->add_render_attribute( 'shortcode', $attributes );

      $shortcode   = [];
      $shortcode[] = sprintf( '[contact-form-7 %s]', $this->get_render_attribute_string( 'shortcode' ) );

      return implode("", $shortcode);
   }


   protected function render( $instance = [] ) {
 
      echo do_shortcode( $this->get_shortcode() );
   }

   public function render_plain_content() {
      echo $this->get_shortcode();
   }

}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_CF7 );