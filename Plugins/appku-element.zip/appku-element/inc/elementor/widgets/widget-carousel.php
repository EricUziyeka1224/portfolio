<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Carousel
class appku_Widget_Carousel extends Widget_Base {
 
   public function get_name() {
      return 'carousel';
   }
 
   public function get_title() {
      return esc_html__( 'Carousel', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-carousel';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'Carousel_section',
         [
            'label' => esc_html__( 'Carousel Image', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'title',
         [
            'label' => __( 'Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Cheap & Trusted Taxi Company', 'appku' ),
         ]
      );

      $this->add_control(
         'text',
         [
            'label' => __( 'Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => __( 'Enjoy your comfortable ride with appku company taxi', 'appku' ),
         ]
      );

      $this->add_control(
         'button',
         [
            'label' => __( 'Button Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Learn More', 'appku' ),
         ]
      );

      $this->add_control(
         'button_url',
         [
            'label' => __( 'Button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' =>  '#',
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );
      $this->add_inline_editing_attributes( 'text', 'basic' );
      $this->add_inline_editing_attributes( 'button', 'basic' );
      $this->add_inline_editing_attributes( 'button_url', 'basic' );
      ?>



      <?php
   }

}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Carousel );