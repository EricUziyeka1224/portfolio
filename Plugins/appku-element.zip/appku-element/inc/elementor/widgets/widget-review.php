<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Review
class appku_Widget_Review extends Widget_Base {
 
   public function get_name() {
      return 'Review';
   }
 
   public function get_title() {
      return esc_html__( 'Review', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-review';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'review_section',
         [
            'label' => esc_html__( 'review', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'ppp',
         [
            'label' => __( 'Number of Review', 'appku' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
               'no' => [
                  'min' => 0,
                  'max' => 100,
                  'step' => 1,
               ],
            ],
            'default' => [
               'size' => 9,
            ]
         ]
      );

      $this->add_control(
         'order',
         [
            'label' => __( 'Order', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'ASC',
            'options' => [
               'ASC'  => __( 'Ascending', 'appku' ),
               'DESC' => __( 'Descending', 'appku' )
            ],
         ]
      );

      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();
      
      //Inline Editing
      $this->add_inline_editing_attributes( 'ppp', 'basic' );
      ?>

      <div class="container">
         <div class="review">
            <div class="row">
         <?php
         $review = new \WP_Query( array( 
               'post_type' => 'review',
               'posts_per_page' => $settings['ppp']['size'],
               'order' => $settings['order'],
            ));

            /* Start the Loop */
            while ( $review->have_posts() ) : $review->the_post(); 

              $review_terms = get_the_terms( get_the_ID() , 'review_category' );

            ?>
            <div class="col-md-4">
               <div class="appku-review-item">
                  <a href="<?php the_permalink() ?>">
                     <?php the_post_thumbnail( 'appku-600x770' ) ?>
                     <?php the_title( '<h4>', '</h4>' ) ?>
                  </a>
               </div>
            </div>

            <?php 
            endwhile; 
            wp_reset_postdata();
         ?>
            </div>
         </div>
      </div>

      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Review );