<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Testimonials
class appku_Widget_Testimonials extends Widget_Base {
 
   public function get_name() {
      return 'testimonials';
   }
 
   public function get_title() {
      return esc_html__( 'Testimonials', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-testimonial';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'testimonials_section',
         [
            'label' => esc_html__( 'Testimonials', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'style',
         [
            'label' => __( 'Style', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style_1',
            'options' => [
               'style_1' => __( 'Style 1', 'appku' ),
               'style_2' => __( 'Style 2', 'appku' )
            ],
         ]
      );

      $this->add_control(
         'align',
         [
            'label' => __( 'Alignment', 'appku' ),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
               'text-left' => [
                  'title' => __( 'Left', 'appku' ),
                  'icon' => 'fa fa-align-left',
               ],
               'text-center' => [
                  'title' => __( 'Center', 'appku' ),
                  'icon' => 'fa fa-align-center',
               ]
            ],
            'default' => 'text-center',
            'toggle' => true
         ]
      );

      $testimonial = new \Elementor\Repeater();

      $testimonial->add_control(
         'image',
         [
            'label' => __( 'Choose Photo', 'appku' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
         ]
      );
      
      $testimonial->add_control(
         'name',
         [
            'label' => __( 'Name', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Michel Jhon', 'appku' ),
         ]
      );

      $testimonial->add_control(
         'designation',
         [
            'label' => __( 'Designation', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Graphic Designer', 'appku' ),
         ]
      );


      $testimonial->add_control(
         'testimonial',
         [
            'label' => __( 'Testimonial', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => __( 'But I must explain to you how all this mistaken idea denouncing pleasure and praising pain was born and will give you a complete account of the system and expound the actual teachings.', 'appku' ),
         ]
      );

      $this->add_control(
         'testimonial_list',
         [
            'label' => __( 'Testimonial List', 'appku' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $testimonial->get_controls(),
            'title_field' => '{{ name }}',
         ]
      );
      
      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display(); ?>

      
         <div class="<?php if ( $settings['style'] == 'style_1' ){ echo'testimonial-active'; }elseif( $settings['style'] == 'style_2' ){ echo'testimonial-2-active'; }?> <?php echo esc_attr( $settings['align'] ); ?>">
         <?php foreach (  $settings['testimonial_list'] as $index => $testimonial ):
         $testimonialText = $this->get_repeater_setting_key( 'testimonial','testimonial_list',$index);
         $name = $this->get_repeater_setting_key( 'name','testimonial_list',$index);         
         $designation = $this->get_repeater_setting_key( 'designation','testimonial_list',$index);
         $this->add_inline_editing_attributes( $testimonialText, 'basic' );
         $this->add_inline_editing_attributes( $name, 'basic' );         
         $this->add_inline_editing_attributes( $designation, 'basic' );
         ?>
         <?php if ($settings['style'] == 'style_1'){ ?>
            <div class="testimonial-wrap">
              <div class="client-text">
                  <p <?php echo $this->get_render_attribute_string( $testimonialText ); ?>><?php echo esc_html($testimonial['testimonial']); ?></p>
              </div>
              <div class="client-info">
                  <h6 <?php echo $this->get_render_attribute_string( $name ); ?>><?php echo esc_html($testimonial['name']); ?></h6>
                  <span <?php echo $this->get_render_attribute_string( $designation ); ?>><?php echo esc_html($testimonial['designation']); ?></span>
              </div>
            </div>

            <?php } elseif ($settings['style'] == 'style_2'){ ?>
            
            <div class="col-xl-4">
               <div class="single-testimonial text-center">
                  <div class="t-quote mb-25">
                     <img src="<?php echo get_template_directory_uri() ?>/images/quote1.png" alt="quote">
                  </div>
                  <div class="testimonial-content mb-15">
                     <p>Sorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris.</p>
                  </div>
                  <div class="testimonial-avatar">
                     <h5>Malonu Kasa</h5>
                     <span>Web Designer</span>
                     <div class="t-avatar-img">
                        <img src="img/testimonial/avatar01.png" alt="avatar">
                     </div>
                  </div>
               </div>
            </div>

         <?php } ?>     
         <?php endforeach ?>
         </div>
      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Testimonials );