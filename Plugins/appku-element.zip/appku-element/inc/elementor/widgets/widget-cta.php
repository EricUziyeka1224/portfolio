<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Call to Action
class appku_Widget_CTA extends Widget_Base {
 
   public function get_name() {
      return 'call_to_action';
   }
 
   public function get_title() {
      return esc_html__( 'Call to Action', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-call-to-action';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }

   protected function _register_controls() {

      $this->start_controls_section(
         'cta_section',
         [
            'label' => esc_html__( 'Call to Action', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );
      
      $this->add_control(
         'bg_img',
         [
            'label' => __( 'Backgroun Image', 'appku' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
         ]
      );

      $this->add_control(
         'overlay',
         [
            'label' => __( 'Overlay', 'appku' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range' => [
               'px' => [
                  'min' => 0,
                  'max' => 99,
                  'step' => 1,
               ]
            ],
            'default' => [
               'unit' => 'px',
               'size' => 30,
            ]
         ]
      );
      
      $this->add_control(
         'title',
         [
            'label' => __( 'Title', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Do you have any projects?  Contact us.', 'appku' )
         ]
      );

      $this->add_control(
         'btn_text',
         [
            'label' => __( 'Button Text', 'appku' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Contact Us', 'appku' )
         ]
      );

      $this->add_control(
         'btn_url',
         [
            'label' => __( 'Button URL', 'appku' ),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://example.com', 'appku' ),
            'show_external' => true,
            'default' => [
               'url' => '#',
               'is_external' => true,
               'nofollow' => true,
            ],
         ]
      );
      
      $this->end_controls_section();

   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display();

      //Inline Editing
      $this->add_inline_editing_attributes( 'title', 'basic' );
      $this->add_inline_editing_attributes( 'btn_text', 'basic' );
      ?>
      
      <section class="appku-call-to-action" style="background: url(<?php echo esc_url( $settings['bg_img']['url'] ); ?>) center top no-repeat;">
         <div class="overlay" style="background: rgba(0,0,0,0.<?php echo esc_attr($settings['overlay']['size']) ?>);">
           <div class="container">
               <div class="row">
                    <div class="col-md-8 text-left align-self-center">
                        <h2 <?php echo $this->get_render_attribute_string( 'title' ); ?> style="color: <?php if ($settings['overlay']['size'] > 15){ echo '#fff'; }?>"><?php echo esc_html($settings['title']); ?></h2>
                     </div>
                     <div class="col-md-4 text-right align-self-center">
                        <a href="<?php echo esc_url( $settings['btn_url']['url'] ); ?>" <?php echo esc_attr($target) . esc_attr($nofollow) ?> <?php echo $this->get_render_attribute_string( 'btn_text' ); ?> href="#"><?php echo esc_html($settings['btn_text']); ?></a>
                    </div>
                </div>
            </div>
         </div>
    </section>
      <?php
   }
 
}

Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_CTA );