<?php 
namespace Elementor;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// Post
class appku_Widget_Post extends Widget_Base {
 
   public function get_name() {
      return 'post';
   }
 
   public function get_title() {
      return esc_html__( 'Post', 'appku' );
   }
 
   public function get_icon() { 
        return 'eicon-posts-carousel';
   }
 
   public function get_categories() {
      return [ 'appku-elements' ];
   }


   protected function _register_controls() {
      $this->start_controls_section(
         'post_section',
         [
            'label' => esc_html__( 'Post', 'appku' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

        $this->add_control(
         'style',
         [
            'label' => __( 'Style', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'style_1',
            'options' => [
               'style_1'  => __( 'Style 1', 'appku' ),
               'style_2' => __( 'Style 2', 'appku' ),
               'style_3' => __( 'Style 3', 'appku' ),
               'none' => __( 'None', 'appku' )
            ],
         ]
      );

      $this->add_control(
         'posts_per_page',
         [
            'label' => __( 'Posts per page', 'appku' ),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 3,
         ]
      );

      $this->add_control(
         'order',
         [
            'label' => __( 'Order', 'appku' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => [
               'ASC'  => __( 'Ascending', 'appku' ),
               'DESC' => __( 'Descending', 'appku' )
            ],
         ]
      );
      
      $this->end_controls_section();
   }

   protected function render( $instance = [] ) {
 
      // get our input from the widget settings.
       
      $settings = $this->get_settings_for_display(); ?>

      <div class="container">
         <div class="row justify-content-center">
               <?php
               $Post = new \WP_Query( array( 
                  'post_type' => 'post',
                  'posts_per_page' => $settings['posts_per_page'],
                  'ignore_sticky_posts' => true,
                  'order' => $settings['order'],
               ));
               /* Start the Loop */
               while ( $Post->have_posts() ) : $Post->the_post();
               ?>

               <!-- Post -->
               <?php if ( 'style_1' == $settings['style'] ): ?>
               <div class="col-lg-4 col-sm-6">
                  <div class="appku-post">
                     <div class="appku-post-img">
                        <?php if (has_post_thumbnail()) { ?>
                           <a href="<?php the_permalink() ?>">
                              <img src="<?php echo get_the_post_thumbnail_url( get_the_ID(),'appku-360-200'); ?>" alt="<?php the_title() ?>">
                           </a>
                        <?php } ?>
                     </div>
                     
                     <div class="appku-post-content">
                        <span>
                           <?php the_time( 'F j, Y' ) ?>
                        </span>
                        <a href="<?php the_permalink() ?>"><h5><?php echo wp_trim_words( get_the_title(), 8, '...' );?></h5></a>
                        <ul class="list-inline">
                           <li class="list-inline-item">
                              <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?><?php the_author(); ?></a>
                           </li>
                        </ul>       
                     </div>
                  </div>
               </div>
               <?php elseif( 'style_2' == $settings['style'] ): ?>
                  
               <?php endif ?>
               <?php 
               endwhile; 
            wp_reset_postdata();
            ?>
         </div>
      </div>

      <?php
   }
 
}
Plugin::instance()->widgets_manager->register_widget_type( new appku_Widget_Post );