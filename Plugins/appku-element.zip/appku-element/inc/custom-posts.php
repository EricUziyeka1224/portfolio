<?php


if ( ! function_exists('appku_custom_post_type') ) {
	
    /**
     * Register a custom post type.
     *
     * @link http://codex.wordpress.org/Function_Reference/register_post_type
     */
    function appku_custom_post_type() {

        global $appku_opt;

        $review_slug = !empty($appku_opt['review_slug']) ? $appku_opt['review_slug'] : 'review';

        //Portfolio
        register_post_type( 'portfolio', array(
                'labels'             => array(
                'name'               => _x( 'Portfolio', 'post type general name', 'appku' ),
                'singular_name'      => _x( 'Portfolio', 'post type singular name', 'appku' ),
                'menu_name'          => _x( 'Portfolio', 'admin menu', 'appku' ),
                'name_admin_bar'     => _x( 'Portfolio', 'add new on admin bar', 'appku' ),
                'add_new'            => _x( 'Add New', 'Portfolio', 'appku' ),
                'add_new_item'       => __( 'Add New Portfolio', 'appku' ),
                'new_item'           => __( 'New Portfolio', 'appku' ),
                'edit_item'          => __( 'Edit Portfolio', 'appku' ),
                'view_item'          => __( 'View Portfolio', 'appku' ),
                'all_items'          => __( 'All Portfolio', 'appku' ),
                'search_items'       => __( 'Search Portfolio', 'appku' ),
                'parent_item_colon'  => __( 'Parent Portfolio:', 'appku' ),
                'not_found'          => __( 'No Portfolio found.', 'appku' ),
                'not_found_in_trash' => __( 'No Portfolio found in Trash.', 'appku' )
            ),

            'description'        => __( 'Description.', 'appku' ),
            'menu_icon'          => 'dashicons-slides',
            'public'             => true,
            'show_in_menu'       => true,
            'has_archive'        => false,
            'hierarchical'       => true,
            'rewrite'            => array( 'slug' => 'portfolio' ),
            'supports'           => array( 'title', 'editor', 'thumbnail' )
        ));

        // Portfolio Taxonomy
        register_taxonomy( 'portfolio_category', 'portfolio', array(
                'labels' => array(
                    'name' => __( 'Portfolio Category', 'appku' ),
                    'add_new_item'      => __( 'Add New Category', 'appku' ),
                ),
                'hierarchical' => true,
                'show_admin_column'     => true
        ));

        // Review 
        register_post_type( 'review', array(
                'labels' => array(
                    'name' => __( 'Reviews' ),
                    'singular_name' => __( 'review' )
                ),
                'menu_icon'   => 'dashicons-clipboard',
                'public' => true,
                'has_archive' => true,
                'rewrite' => array( 'slug' => $review_slug ),
                'supports' => array( 'title', 'editor', 'thumbnail', 'comments' )
                
            )
        );

        //Cars
        register_post_type( 'cars', array(
                'labels'             => array(
                'name'               => _x( 'Cars', 'post type general name', 'appku' ),
                'singular_name'      => _x( 'Car', 'post type singular name', 'appku' ),
                'menu_name'          => _x( 'Cars', 'admin menu', 'appku' ),
                'name_admin_bar'     => _x( 'Car', 'add new on admin bar', 'appku' ),
                'add_new'            => _x( 'Add New', 'Car', 'appku' ),
                'add_new_item'       => __( 'Add New Car', 'appku' ),
                'new_item'           => __( 'New Car', 'appku' ),
                'edit_item'          => __( 'Edit Car', 'appku' ),
                'view_item'          => __( 'View Car', 'appku' ),
                'all_items'          => __( 'All Car', 'appku' ),
                'search_items'       => __( 'Search Car', 'appku' ),
                'parent_item_colon'  => __( 'Parent Car:', 'appku' ),
                'not_found'          => __( 'No Car found.', 'appku' ),
                'not_found_in_trash' => __( 'No Car found in Trash.', 'appku' )
            ),

            'description'        => __( 'Description.', 'appku' ),
            'menu_icon'          => 'dashicons-layout',
            'public'             => true,
            'show_in_menu'       => true,
            'has_archive'        => false,
            'hierarchical'       => true,
            'rewrite'            => array( 'slug' => 'cars' ),
            'supports'           => array( 'title', 'editor', 'thumbnail' )
        ));

        // Cars Taxonomy
        register_taxonomy( 'cars_category', 'cars', array(
                'labels' => array(
                    'name' => __( 'Cars Category', 'appku' ),
                    'add_new_item'      => __( 'Add New Category', 'appku' ),
                ),
                'hierarchical' => true,
                'show_admin_column'     => true
        ));


        // Mega Menu
        register_post_type( 'megamenu', array(
                'labels' => array(
                    'name' => __( 'Mega Menu' ),
                    'singular_name' => __( 'Menu' ),
                    'add_new_item'       => __( 'Add New Menu', 'appku' ),
                ),
                'menu_icon'   => 'dashicons-menu',
                'public' => true,
                'has_archive' => true,
                'rewrite' => array( 'slug' => 'mega-menu' ),
                'supports' => array( 'title', 'editor' )
                
            )
        );
    }

    add_action( 'init', 'appku_custom_post_type' );

}