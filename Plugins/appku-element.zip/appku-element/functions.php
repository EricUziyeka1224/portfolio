<?php 
// appku Social Sharing
function appku_social_sharing() {
  global $post;  
  $share_url = get_permalink( $post->ID );
  $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
  $postimg = $large_image_url[0];
  $posttitle = get_the_title( $post->ID );
  ?>
    <ul>
      <li><a href="#" onclick="javascript: window.open('<?php echo esc_url('https://www.facebook.com/sharer/sharer.php?u='.$share_url); ?>'); return false;" title="Facebook" target="_blank"><?php echo esc_html__( 'Facebook','appku' ) ?>,</a></li>
      <li><a href="#" title="Twitter" onclick="javascript: window.open('<?php echo esc_url('https://twitter.com/home?status='.$posttitle.'&nbsp;'.$share_url); ?>'); return false;" target="_blank"><?php echo esc_html__( 'Twitter','appku' ) ?>,</a></li>
      <li><a href="#" onclick="javascript: window.open('<?php echo esc_url('https://plus.google.com/share?url='.$share_url); ?>'); return false;" title="Google +" target="_blank"><?php echo esc_html__( 'Google','appku' ) ?></a></li>
    </ul>
  <?php
}