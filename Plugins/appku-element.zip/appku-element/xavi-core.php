<?php
/**
* Plugin Name: Appku Element
* Plugin URI: https://github.com/farhan01617/appku-element
* Description: After install the appku WordPress Theme, you must need to install this "appku Element" first to get all functions of appku WP Theme.
* Version: 1.0.0
* Author: ThemeBing
* Author URI: http://themeforest.net/user/ThemeBing
* Text Domain: appku
* License: GPL/GNU.
*/


/**----------------------------------------------------------------*/
/* Include all file
/*-----------------------------------------------------------------*/  

include_once(dirname( __FILE__ ). '/functions.php');
include_once(dirname( __FILE__ ). '/inc/elementor/elementor.php');
include_once(dirname( __FILE__ ). '/inc/recent-posts-widget.php');